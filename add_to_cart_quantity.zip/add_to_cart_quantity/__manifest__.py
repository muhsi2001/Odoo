{
    'name': 'Add To Cart Quantity',
    'depends': ['website'],
    'data': [
        'views/website_shop_views.xml'
    ]
}