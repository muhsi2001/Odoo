from . import product_details
