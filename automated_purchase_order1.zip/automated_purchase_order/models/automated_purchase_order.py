# -*- coding: utf-8 -*-

from odoo import fields, models


class AutomatedPurchaseOrder(models.Model):
    _name = "automated.purchase.order"
    _description = "automated purchase order"

    # name = fields.Char()
