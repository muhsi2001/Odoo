from odoo import Command
from odoo import api, fields, models


class ProductDetails(models.TransientModel):
    _name = 'product.details'

    product_id = fields.Many2one(comodel_name='product.template', string='Product')
    quantity = fields.Integer('Quantity', help='Quantity of the product')
    price = fields.Float('Price', help='Price of the product')
    vendor_id = fields.Many2one(comodel_name='res.partner',string='Vendor')
    date = fields.Date.today()

    def create_rfq_po_bill(self):
        for vendor in self.product_id.seller_ids:
            existing_rfq = self.env['purchase.order'].search([
                ('partner_id', '=', vendor.partner_id[0].id),
                ('state', 'in', ['draft']),
            ])

            if existing_rfq:
                existing_rfq.write({
                    'order_line':[fields.Command.create({
                        'product_id': self.product_id.product_variant_id.id,
                        'product_qty': self.quantity,
                        'price_unit': self.price
                })]
                })
                existing_rfq.button_confirm()
            else:
                rfq = self.env['purchase.order'].create({
                    'partner_id': vendor.partner_id[0].id,
                    'order_line': [(fields.Command.create({
                        'product_id': self.product_id.product_variant_id.id,
                        'product_qty': self.quantity,
                        'price_unit': self.price
                    })
                    )]
                })
                rfq.button_confirm()
                domain = ['|', ('result_package_id', 'in', self.ids),
                          ('package_id', 'in', self.ids)]
                pickings = self.env['stock.move.line'].search(domain).mapped(
                    'picking_id')
                print(rfq.picking_ids)
                pickings.button_validate()

                
                # rfq.action_create_invoice()
                # action_create_invoice()

                bill = self.env['account.move'].create({
                    'partner_id': vendor.partner_id[0].id,
                    'invoice_date': self.date,
                    # 'invoice_line_ids': [],
                    'move_type': 'in_invoice',
                    'invoice_line_ids': [Command.create({
                        'product_id': self.product_id.product_variant_id.id,
                        'quantity': self.quantity,
                        'price_unit': self.price
                    })]
                })
                bill.action_post()





                # rfq.button_confirm()

                # bill = self.env['account.move'].create({
                #     'partner_id': vendor.partner_id[0].id,
                #     'invoice_date': self.date,
                #     # 'invoice_line_ids': [],
                #     'move_type': 'in_invoice',
                #     'invoice_line_ids': [Command.create({
                #         'product_id': self.product_id.product_variant_id.id,
                #         'quantity': self.quantity,
                #         'price_unit': self.price
                #     })]
                # })
                # bill.action_post()


