from . import product_template
from . import automated_purchase_order
