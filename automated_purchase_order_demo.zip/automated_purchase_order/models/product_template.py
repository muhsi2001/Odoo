# -*- coding: utf-8 -*-

from odoo import fields, models


class ProductTemplate(models.Model):

    _inherit = "product.template"


    def action_open_wizard(self):
        # product_id = self.env['product.template'].search([])
        # vendor = self.product_id.seller_ids.partner_id[0].id
        return {
            'name': 'Product Details',
            'view_mode': 'form',
            'res_model': 'product.details',
            'view_id': self.env.ref('automated_purchase_order.product_details_form').id,
            'type': 'ir.actions.act_window',
            'target': 'new',
            'context': {
                'default_product_id': self.id
            }
        }