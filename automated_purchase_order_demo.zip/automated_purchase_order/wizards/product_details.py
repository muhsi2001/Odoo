from odoo import api, fields, models


class ProductDetails(models.TransientModel):
    _name = 'product.details'

    product_id = fields.Many2one(comodel_name='product.template', string='Product')
    quantity = fields.Integer('Quantity', help='Quantity of the product')
    price = fields.Float('Price', help='Price of the product')
    vendor_id = fields.Many2one(comodel_name='res.partner',string='Vendor')
    date = fields.Date.today()

    # @api.model
    # def default_get(self, fields):
    #     res = super(ProductDetails, self).default_get(fields)
    #     active_id = self.env.context.get('active_id')
    #     product = self.env['product.template'].browse(active_id)
    #     res.update({
    #         'product_id': product.id
    #     })
    #     return res

    def create_rfq_po_bill(self):
        # for vendor in product_id.seller_ids:
        # vendor_id = self.product_id.seller_ids.partner_id[0].id

        existing_rfq = self.env['purchase.order'].search([
            ('partner_id', '=', self.vendor_id.id),
            ('state', 'in', ['draft', 'sent']),
            # ('order_line.product_id', '=', self.product_id.id),
        ], limit=1)

        if existing_rfq:
            existing_rfq.write({
                'order_line': [(0, 0, {
                    'product_id': self.product_id.product_variant_id.id,
                    'product_qty': self.quantity,
                    'price_unit': self.price
                })],
            })
        else:
            rfq = self.env['purchase.order'].create({
                'partner_id': self.vendor_id.id,
                'order_line': [(fields.Command.create({
                    'product_id': self.product_id.product_variant_id.id,
                    'product_qty': self.quantity,
                    'price_unit': self.price
                })
                )]
            })

            self.env['purchase.order'].create({
                'partner_id': self.vendor_id.id,
                'origin': rfq.name,
                'order_line': [(fields.Command.create({
                    'product_id': self.product_id.product_variant_id.id,
                    'product_qty': self.quantity,
                    'price_unit': self.price
                })
                )]
            }).write({
                'state': 'purchase'
            })

            bill_data = {
                'partner_id': self.vendor_id.id,
                'invoice_date': self.date,
                'invoice_line_ids': [],
                'move_type': 'in_invoice'
            }
            bill_data['invoice_line_ids'].append((0, 0, {
                'product_id': self.product_id.product_variant_id.id,
                'quantity': self.quantity,
                'price_unit': self.price
            }))
            bill = self.env['account.move'].create(bill_data)
            bill.action_post()

        # existing_po = self.env['purchase.order'].search([
        #     ('partner_id', '=', self.vendor_id.id),
        #     ('state', 'in', ['draft', 'sent']),
        #     # ('order_line.product_id', '=', self.product_id.id),
        # ], limit=1)
        #
        # if existing_po:
        #     existing_po.write({
        #         'origin': existing_rfq.name,
        #         'order_line': [(0, 0, {
        #             'product_id': self.product_id.product_variant_id.id,
        #             'product_qty': self.quantity,
        #             'price_unit': self.price
        #         })],
        #     })
        #
        # else:
        #     self.env['purchase.order'].create({
        #         'partner_id': self.vendor_id.id,
        #         'origin': rfq.name,
        #         'order_line': [(fields.Command.create({
        #             'product_id': self.product_id.product_variant_id.id,
        #             'product_qty': self.quantity,
        #             'price_unit': self.price
        #         })
        #         )]
        #     }).write({
        #         'state': 'purchase'
        #     })
        #
        # existing_bill = self.env['account.move'].search([
        #     ('partner_id', '=', self.vendor_id.id),
        #     # ('state', 'in', ['draft', 'sent']),
        #     # ('order_line.product_id', '=', self.product_id.id),
        # ], limit=1)
        #
        # if existing_bill:
        #     bill_data = {
        #         'partner_id': self.vendor_id.id,
        #         'invoice_date': self.date,
        #         'invoice_line_ids': [],
        #         'move_type': 'in_invoice'
        #     }
        #     bill_data['invoice_line_ids'].append((0, 0, {
        #         'product_id': self.product_id.id,
        #         'quantity': self.quantity,
        #         'price_unit': self.price
        #     }))
        #     bill = self.env['account.move'].create(bill_data)
        #     bill.action_post()
        #     # bill.action_register_payment()
        #
        # else:
        #     bill_data = {
        #         'partner_id': self.vendor_id.id,
        #         'invoice_date': self.date,
        #         'invoice_line_ids': [],
        #         'move_type': 'in_invoice'
        #     }
        #     bill_data['invoice_line_ids'].append((0, 0, {
        #         'product_id': self.product_id.product_variant_id.id,
        #         'quantity': self.quantity,
        #         'price_unit': self.price
        #     }))
        #     bill = self.env['account.move'].create(bill_data)
        #     bill.action_post()

            # rfq = self.env['purchase.order'].create({
            #     'partner_id': self.vendor_id.id,
            #     'order_line': [(fields.Command.create({
            #         'product_id': self.product_id.product_variant_id.id,
            #         'product_qty': self.quantity,
            #         'price_unit': self.price
            #     })
            #     )]
            # })
            #
            # self.env['purchase.order'].create({
            #     'partner_id': self.vendor_id.id,
            #     'origin': rfq.name,
            #     'order_line': [(fields.Command.create({
            #         'product_id': self.product_id.product_variant_id.id,
            #         'product_qty': self.quantity,
            #         'price_unit': self.price
            #     })
            #     )]
            # }).write({
            #     'state': 'purchase'
            # })
            #
            # bill_data = {
            #     'partner_id': self.vendor_id.id,
            #     'invoice_date': self.date,
            #     'invoice_line_ids': [],
            #     'move_type': 'in_invoice'
            # }
            # bill_data['invoice_line_ids'].append((0, 0, {
            #     'product_id': self.product_id.product_variant_id.id,
            #     'quantity': self.quantity,
            #     'price_unit': self.price
            # }))
            # bill= self.env['account.move'].create(bill_data)
            # bill.action_post()
            # bill.action_register_payment()
