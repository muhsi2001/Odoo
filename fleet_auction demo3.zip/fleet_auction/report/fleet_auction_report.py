from odoo import api, models
from odoo.exceptions import UserError


class FleetAuctionReport(models.AbstractModel):
    _name = 'report.fleet_auction.report_fleet_auction'

    @api.model
    def _get_report_values(self, data, docids=None):
        print('test', docids)
        docs = self.env['fleet.auction'].browse(docids)
        print(docs)
        if data:
            return {'doc_ids': docids,
                    'doc_model': 'fleet.auction',
                    'docs': docs,
                    'data': data,
                    }
        else:
            raise UserError('No data to print')
