# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Fleet Auction',
    'version': '17.0.1.0.0',
    'category': 'Human Resources/Fleet Auction',
    'author': "Mike",
    'description': "Fleet Auction",
    'summary': "Manages fleet auction activities.",
    'depends': ['fleet'],
    'data': [
        'security/ir.model.access.csv',
        'views/fleet_auction_menu.xml',
        'views/fleet_auction_views.xml'
    ],
    'installable':True,
    'application':True
}
