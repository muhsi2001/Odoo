# -*- coding: utf-8 -*-

from odoo import models, fields


class FleetAuction(models.Model):
    _name = "fleet.auction"
    _description = "fleet auction"
    _inherit = 'mail.thread'

    name = fields.Char('Name',help='Name of the vehicle', copy=False,
                       required=True)
    vehicle_id = fields.Many2one(
        'fleet.vehicle.model', string="Vehicle Name",
        help='Name of the vehicle')
    brand = fields.Char('Brand',help='Brand of the vehicle')
    responsible_id = fields.Many2one(
        'res.users', string='Responsible',
        default=lambda self: self.env.user,
        help='Person who is responsible for the auction')
    start_date = fields.Date('Start Date',help='Starting date of the auction')
    end_date = fields.Date('End Date',help='Ending date of the auction')
    active = fields.Boolean('Active', default=True)
    state = fields.Selection(
         string='State',
         tracking=True,
         default='draft',
         selection=[('draft', 'Draft'), ('confirmed', 'Confirmed'),
                    ('ongoing', 'Ongoing'), ('success', 'Success'),
                    ('cancelled', 'Cancelled')])
    description = fields.Html('Description', help='Description about the auction')
    image = fields.Image('Image', help='Image of the auction')
    company_id = fields.Many2one('res.company',
                                 'Company',
                                 default=lambda self: self.env.company)
    currency_id = fields.Many2one('res.currency',
                                related='company_id.currency_id', default=lambda
                                self: self.env.user.company_id.currency_id.id)
    start_price = fields.Monetary('Start Price', copy=False,
                                  help='Price when the auction starts')
    won_price = fields.Monetary('Won Price', copy=False,
                                help='The price at which the vehicle is won')
    customer_id = fields.Many2one('res.partner', 'Customer',
                                  help='Person participating in the auction')
