# -*- coding: utf-8 -*-

from odoo import api, fields, models
from odoo.exceptions import ValidationError


class FleetAuction(models.Model):
    _name = "fleet.auction"
    _description = "fleet auction"
    _inherit = 'mail.thread'

    name = fields.Char(
        'Name', help='Name of the vehicle', copy=False,
        required=True)

    vehicle_id = fields.Many2one(
        'fleet.vehicle.model', string="Vehicle Name",
        help='Name of the vehicle')
    brand = fields.Char('Brand', help='Brand of the vehicle')
    responsible_id = fields.Many2one(
        'res.users', string='Responsible',
        default=lambda self: self.env.user,
        help='Person who is responsible for the auction')
    start_date = fields.Date(
        'Start Date', help='Starting date of the auction')
    end_date = fields.Date(
        'End Date', help='Ending date of the auction')
    active = fields.Boolean(
        'Active', default=True,
        help='If active is set to false,'
             'the data will be archived')
    bid_count = fields.Integer(
        string='Bid Count', compute='_compute_bid_count')
    state = fields.Selection(
         string='State',
         tracking=True,
         default='draft',
         selection=[('draft', 'Draft'), ('confirmed', 'Confirmed'),
                    ('ongoing', 'Ongoing'), ('success', 'Success'),
                    ('cancelled', 'Cancelled')])
    description = fields.Html(
        'Description', help='Description about the auction')
    image = fields.Image('Image', help='Image of the auction')
    company_id = fields.Many2one(
        'res.company', 'Company',
        default=lambda self: self.env.company,
        help='Company which conducts the auction')
    currency_id = fields.Many2one(
        'res.currency',
        related='company_id.currency_id',
        default=lambda
        self: self.env.company.currency_id.
        id)
    start_price = fields.Monetary(
        'Start Price', copy=False,
        help='Price when the auction starts')

    won_price = fields.Monetary(
        'Won Price', copy=False,
        help='The price at which the vehicle is won')

    customer_id = fields.Many2one(
        'res.partner', 'Customer',
        help='Person participating in the auction', )

    phone_id = fields.Char(
        string='Phone', related='customer_id.phone',
        readonly=False,
        help='Phone Number of the customer')

    email_id = fields.Char(
        string='Email', related='customer_id.email',
        readonly=False, help='Email address of the customer')

    tags = fields.Many2many(
        'crm.tag', string='Tags')

    bid = fields.One2many(
        'auction.bid', inverse_name='auction_id',
        compute='_compute_confirmed_bids')

    def button_confirm(self):
        """Function defined to change state to confirmed"""
        self.write({
            'state': "confirmed"
        })

    def button_end(self):
        """Function defined to change the state to success"""
        self.write({
            'state': "success"
        })

    def button_cancel(self):
        """Function defined to change the state to cancelled"""
        self.write({
            'state': "cancelled"
        })

    def button_stop(self):
        """Function defined to change the state to success"""
        self.write({
            'state': "success"
        })

        sorted_bids = self.bid.sorted(key=lambda bid: bid.bid_amt, reverse=True)

        if sorted_bids:
            # Fill auction form with winning bid customer info
            winning_bid = sorted_bids[0]
            self.write({'customer_id': winning_bid.customer,
                        'won_price': winning_bid.bid_amt})

    @api.constrains('start_date', 'end_date')
    def _check_dates(self):
        """Function defined to check the validation of dates"""
        for auction in self:
            if auction.end_date and auction.start_date > auction.end_date:
                raise ValidationError((
                    'Auction start date must be smaller than end date.'
                ))

    def _compute_bid_count(self):
        """Function defined to count the bids of a particular auction"""
        for rec in self:
            bid_count = (self.env['auction.bid'].search_count
                         ([('auction_id', '=', rec.name)]))
            rec.bid_count = bid_count

    def _compute_confirmed_bids(self):
        """Function defined to retrieve only confirmed bids to the auction"""
        for rec in self:
            bid = (self.env['auction.bid'].search([
                ('state', '=', 'confirmed'),
                ('auction_id', '=', rec.name)
            ]))
            rec.bid = bid

    def action_open_bids(self):
        """Function defined to return the 
        views while opening the smart button"""
        return {
             'type': 'ir.actions.act_window',
             'name': 'Bids',
             'view_mode': 'tree,form',
             'res_model': 'auction.bid',
             'domain': [('auction_id', '=', self.name)],
             'target': 'current'
         }
