from odoo import models


class AccountMove(models.Model):

    _inherit = "account.move"

    def send_email_to_customer(self):
        mail_template = self.env.ref('fleet_auction.eauction_invoice_email_template')
        mail_template.send_mail(self.id, force_send=True)

    def action_post(self):
        result = super(AccountMove, self).action_post()
        self.send_email_to_customer()
        return result
