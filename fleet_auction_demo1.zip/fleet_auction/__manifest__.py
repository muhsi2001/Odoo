# -*- coding: utf-8 -*-

{
    'name': 'Fleet Auction',
    'version': '17.0.1.0.0',
    'category': 'Human Resources/Fleet Auction',
    'author': "Mike",
    'description': "Fleet Auction",
    'summary': "Manages fleet auction activities.",
    'depends': ['fleet', 'account'],
    'data': [
        'security/auction_security.xml',
        'security/ir.model.access.csv',
        'data/mail_template.xml',
        'data/auction_end_template.xml',
        'data/auction_sequence.xml',
        'data/start_and_end_date_cron.xml',
        'wizards/cancel_auction.xml',
        'views/fleet_auction_menu.xml',
        'views/fleet_auction_views.xml',
        'views/auction_expense_view.xml',
        'views/auction_bid_menu.xml',
        'views/auction_bid_views.xml',
        'views/fleet_vehicle_views.xml'
    ],
    'installable': True,
    'application': True
}
