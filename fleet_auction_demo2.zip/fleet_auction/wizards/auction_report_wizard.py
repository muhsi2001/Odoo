from odoo import fields, models


class AuctionWizard(models.TransientModel):
    _name = 'auction.wizard'

    from_date = fields.Date(
        string='From Date',
        help='The wizard will generate report on and after this date')
    to_date = fields.Date(
        string='To Date',
        help='The wizard will generate report on and before this date')
    state = fields.Selection(
        string='State',
        selection=[('draft', 'Draft'),
                   ('confirmed', 'Confirmed'),
                   ('ongoing', 'Ongoing'),
                   ('success', 'Success'),
                   ('cancelled', 'Cancelled')],
        help='Stages of the auction')
    customer_id = fields.Many2one(string='Customer', comodel_name='res.partner',
                                  help='Customer participated in the auction')
    responsible_id = fields.Many2one(string='Responsible',
                                     comodel_name='res.users',
                                     help='Person responsible for the auction')

    def print_report(self):
        data = {
            'from_date': self.from_date,
            'to_date': self.to_date,
            'state': self.state,
            'customer_id': self.customer_id,
            'responsible_id': self.responsible_id
        }

        return self.env.ref('fleet_auction.action_report_fleet_auction').report_action(
            None, data=data)
