{
    'name': 'Multi Company Products',
    'version': '17.0.1.0.0',
    'category': 'Marketing/Multi Company Products',
    'author': "Mike",
    'description': "Multi Company Products",
    'summary': "Multi Company Products",
    'depends': ['purchase'],
    'data': [
        'security/ir.model.access.csv',
        'security/product_security.xml',
        'views/multi_company_products_views.xml',
        'views/multi_company_products_menu.xml'
        ]
}