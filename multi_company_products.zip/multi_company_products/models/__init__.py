# -*- coding: utf-8 -*-

from . import multi_company_products
from . import product_template
