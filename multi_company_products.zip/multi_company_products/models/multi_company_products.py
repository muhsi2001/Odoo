# -*- coding: utf-8 -*-

from odoo import models


class MultiCompanyProducts(models.Model):
    _name = "multi.company.products"
    _description = "multi company products"
